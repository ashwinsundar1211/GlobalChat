onEvent("button1", "click", function( ) {
  if (getText("label1") == "") {
    setText("label1", "Unknown Name");
  } else {
    setText("label1", getText("text_input1"));
    setText("text_input1", "");
  }
});
onEvent("button2", "click", function( ) {
  createRecord("Messages", {Message_and_Username:(getText("label1") + (" :" + getText("text_input2")))}, function(record) {
    
  });
});
onEvent("button3", "click", function( ) {
  readRecords("Messages", {}, function(records) {
    for (var i =0; i < records.length; i++) {
      setText("text_area1", (records[i]).Message_and_Username);
    }
  });
});
